# HALO AI

Your personal AI assistant (mobile app + backend).

## Project Structure

```
HALO-AI/
├── server/          ← Backend (Node.js + OpenAI)
│   ├── server.js
│   ├── package.json
│   └── .env
│
└── app/             ← Mobile App (Expo / React Native)
    ├── App.js
    ├── app.json
    └── package.json
```

## How to Run

### 1. Backend (server)

1. Open the `server` folder
2. Edit the `.env` file and put your real OpenAI API key:
   ```
   OPENAI_API_KEY=sk-your-real-key-here
   OPENAI_MODEL=gpt-4o-mini
   PORT=3000
   ```
3. In a terminal, run:
   ```bash
   cd server
   npm install
   npm start
   ```

You should see: `HALO AI server running on port 3000`

### 2. Mobile App

1. Open `app/App.js`
2. Find this line:
   ```js
   const API_URL = "http://YOUR_SERVER_IP:3000";
   ```
3. Replace `YOUR_SERVER_IP` with your computer's local IP address  
   (example: `http://192.168.1.45:3000`)

4. In a terminal, run:
   ```bash
   cd app
   npm install
   npx expo start
   ```

5. Scan the QR code with the **Expo Go** app on your phone.  
   Make sure your phone and computer are on the **same Wi-Fi**.

## How to find your computer's IP address

- **Windows**: Open Command Prompt → type `ipconfig` → look for **IPv4 Address**
- **Mac / Linux**: Open Terminal → type `ifconfig` or `ip addr` → look for something like `192.168.x.x`

## Notes

- This version uses local chat history (saved on the phone).
- The AI answers come from OpenAI.
- You can later add voice, images, cloud accounts, etc.

import React, { useEffect, useState } from "react";

import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";

const API_URL = "http://YOUR_SERVER_IP:3000"; // ← Change this to your computer's IP

const STORAGE_KEY = "HALO_AI_CHATS";

export default function App() {

  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadChats();
  }, []);

  async function loadChats() {
    try {
      const saved = await AsyncStorage.getItem(STORAGE_KEY);

      if (saved) {
        const parsed = JSON.parse(saved);
        setChats(parsed);

        if (parsed.length > 0) {
          setActiveChat(parsed[0].id);
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  async function saveChats(newChats) {
    setChats(newChats);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newChats));
  }

  function createChat() {
    const chat = {
      id: Date.now().toString(),
      title: "New Chat",
      messages: []
    };

    saveChats([chat, ...chats]);
    setActiveChat(chat.id);
  }

  const currentChat = chats.find(chat => chat.id === activeChat);

  async function sendMessage() {
    const text = message.trim();

    if (!text || loading) return;

    if (!currentChat) {
      createChat();
      return;
    }

    const userMessage = {
      role: "user",
      content: text
    };

    const newMessages = [...currentChat.messages, userMessage];

    const updatedChats = chats.map(chat => {
      if (chat.id !== currentChat.id) return chat;

      return {
        ...chat,
        title: chat.messages.length === 0 ? text.substring(0, 30) : chat.title,
        messages: newMessages
      };
    });

    setMessage("");
    await saveChats(updatedChats);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          messages: newMessages
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Server error");
      }

      const finalChats = updatedChats.map(chat => {
        if (chat.id !== currentChat.id) return chat;

        return {
          ...chat,
          messages: [
            ...newMessages,
            {
              role: "assistant",
              content: data.message
            }
          ]
        };
      });

      await saveChats(finalChats);

    } catch (error) {
      Alert.alert(
        "HALO AI",
        error.message || "Unable to connect to HALO AI."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />

      {/* HEADER */}
      <View style={styles.header}>
        <View style={styles.brand}>
          <View style={styles.logo}>
            <Text style={styles.logoText}>H</Text>
          </View>

          <View>
            <Text style={styles.title}>HALO AI</Text>
            <Text style={styles.subtitle}>Your AI assistant</Text>
          </View>
        </View>

        <Pressable onPress={createChat} style={styles.newChat}>
          <MaterialCommunityIcons
            name="square-edit-outline"
            size={25}
            color="white"
          />
        </Pressable>
      </View>

      {!currentChat ? (
        <View style={styles.welcome}>
          <Text style={styles.halo}>HALO</Text>
          <Text style={styles.question}>How can I help?</Text>
          <Text style={styles.description}>
            Ask questions, write code, brainstorm ideas and learn.
          </Text>

          <Pressable onPress={createChat} style={styles.startButton}>
            <Text style={styles.startText}>Start a chat</Text>
          </Pressable>
        </View>
      ) : (
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <FlatList
            data={currentChat.messages}
            keyExtractor={(_, index) => index.toString()}
            contentContainerStyle={styles.messages}
            renderItem={({ item }) => (
              <View
                style={[
                  styles.message,
                  item.role === "user" ? styles.userMessage : styles.aiMessage
                ]}
              >
                <Text style={styles.messageRole}>
                  {item.role === "user" ? "YOU" : "HALO"}
                </Text>
                <Text style={styles.messageText}>{item.content}</Text>
              </View>
            )}
            ListFooterComponent={
              loading ? (
                <Text style={styles.thinking}>HALO is thinking...</Text>
              ) : null
            }
          />

          {/* COMPOSER */}
          <View style={styles.composer}>
            <TextInput
              value={message}
              onChangeText={setMessage}
              placeholder="Message HALO AI..."
              placeholderTextColor="#71837d"
              multiline
              style={styles.input}
            />

            <Pressable
              onPress={sendMessage}
              style={[styles.sendButton, !message.trim() && styles.disabled]}
            >
              <MaterialCommunityIcons
                name="arrow-up"
                size={25}
                color="#06100d"
              />
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#06100d"
  },
  header: {
    height: 75,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#19332d"
  },
  brand: {
    flexDirection: "row",
    alignItems: "center"
  },
  logo: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: "#4ecca3",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 11
  },
  logoText: {
    color: "#06100d",
    fontSize: 27,
    fontWeight: "900"
  },
  title: {
    color: "white",
    fontSize: 19,
    fontWeight: "800"
  },
  subtitle: {
    color: "#78928a",
    fontSize: 11,
    marginTop: 2
  },
  newChat: {
    padding: 10
  },
  welcome: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 30
  },
  halo: {
    color: "#4ecca3",
    fontSize: 55,
    fontWeight: "900",
    letterSpacing: 7
  },
  question: {
    color: "white",
    fontSize: 28,
    fontWeight: "800",
    marginTop: 8
  },
  description: {
    color: "#8ba39b",
    textAlign: "center",
    fontSize: 15,
    marginTop: 12,
    lineHeight: 23
  },
  startButton: {
    backgroundColor: "#4ecca3",
    paddingHorizontal: 27,
    paddingVertical: 15,
    borderRadius: 16,
    marginTop: 25
  },
  startText: {
    color: "#06100d",
    fontSize: 16,
    fontWeight: "800"
  },
  messages: {
    padding: 15,
    paddingBottom: 10
  },
  message: {
    maxWidth: "90%",
    padding: 15,
    borderRadius: 18,
    marginBottom: 12
  },
  userMessage: {
    alignSelf: "flex-end",
    backgroundColor: "#173d34"
  },
  aiMessage: {
    alignSelf: "flex-start",
    backgroundColor: "#10201d"
  },
  messageRole: {
    color: "#4ecca3",
    fontSize: 10,
    fontWeight: "900",
    marginBottom: 7
  },
  messageText: {
    color: "#edf7f4",
    fontSize: 16,
    lineHeight: 23
  },
  thinking: {
    color: "#78928a",
    padding: 15,
    fontStyle: "italic"
  },
  composer: {
    margin: 10,
    padding: 7,
    paddingLeft: 15,
    borderRadius: 23,
    borderWidth: 1,
    borderColor: "#29453e",
    backgroundColor: "#0b1b17",
    flexDirection: "row",
    alignItems: "flex-end"
  },
  input: {
    flex: 1,
    color: "white",
    fontSize: 16,
    maxHeight: 120,
    paddingTop: 10,
    paddingBottom: 10
  },
  sendButton: {
    width: 43,
    height: 43,
    borderRadius: 22,
    backgroundColor: "#4ecca3",
    alignItems: "center",
    justifyContent: "center"
  },
  disabled: {
    opacity: 0.35
  }
});
